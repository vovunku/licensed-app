import { h } from 'preact';
export type PendingWidgetProps = {
    parentElement?: Element;
    onClose: () => void;
    onDisconnect: () => void;
};
declare const PendingWidget: (props: PendingWidgetProps) => h.JSX.Element;
export default PendingWidget;
//# sourceMappingURL=PendingWidget.d.ts.map