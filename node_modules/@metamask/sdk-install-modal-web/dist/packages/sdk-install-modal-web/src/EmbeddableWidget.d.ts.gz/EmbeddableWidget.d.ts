import preact from 'preact';
import { InstallWidgetProps } from './InstallWidget';
import { PendingWidgetProps } from './PendingWidget';
export type Renderable = preact.AnyComponent | JSX.Element | preact.JSX.Element;
/**
  Wrapper around Widget, responsible for passing config and other options during widget usage on the
  host page
 */
export default class EmbeddableWidget {
    el: Element;
    component: Renderable;
    render: (parentElement?: Element) => void;
    mount: (props: InstallWidgetProps) => void;
    mountPending: (props: PendingWidgetProps) => void;
    updateOTPValue: (otpValue: string) => void;
    unmount: () => void;
}
//# sourceMappingURL=EmbeddableWidget.d.ts.map