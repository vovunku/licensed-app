import { h } from 'preact';
export type InstallWidgetProps = {
    parentElement?: Element;
    link: string;
    metaMaskInstaller: {
        startDesktopOnboarding: () => void;
    };
    onClose: () => void;
};
declare const InstallWidget: (props: InstallWidgetProps) => h.JSX.Element;
export default InstallWidget;
//# sourceMappingURL=InstallWidget.d.ts.map